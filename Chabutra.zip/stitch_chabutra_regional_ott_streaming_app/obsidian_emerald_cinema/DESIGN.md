---
name: Obsidian Emerald Cinema
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#191c22'
  surface-container: '#1d2026'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2eb'
  on-surface-variant: '#b9cbb9'
  inverse-surface: '#e1e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#849585'
  outline-variant: '#3b4b3d'
  surface-tint: '#00e478'
  primary: '#f1ffef'
  on-primary: '#003919'
  primary-container: '#00ff87'
  on-primary-container: '#007138'
  inverse-primary: '#006d36'
  secondary: '#ffdb9d'
  on-secondary: '#412d00'
  secondary-container: '#feb700'
  on-secondary-container: '#6b4b00'
  tertiary: '#f0fdff'
  on-tertiary: '#00363b'
  tertiary-container: '#71f0ff'
  on-tertiary-container: '#006c76'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#60ff98'
  primary-fixed-dim: '#00e478'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005227'
  secondary-fixed: '#ffdea8'
  secondary-fixed-dim: '#ffba20'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5e4200'
  tertiary-fixed: '#8bf2ff'
  tertiary-fixed-dim: '#43d9e9'
  on-tertiary-fixed: '#001f23'
  on-tertiary-fixed-variant: '#004f56'
  background: '#10131a'
  on-background: '#e1e2eb'
  surface-variant: '#32353c'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a high-octane cinematic darkness calibrated specifically for contemporary regional streaming. It merges deep obsidian nightscapes with hyper-vivid electric emerald and golden amber highlights, capturing both rural cultural vitality and aggressive modern entertainment production value.

The visual tone is uncompromising, prestigious, and intensely immersive. It removes interface friction so video thumbnails, actor portraits, and motion trailers command full visual bandwidth, framed by precision glassmorphic surfaces, disciplined neon accents, and edge highlights that evoke premium physical theater equipment.

### Design Movements & Visual Language
- **Cinematic Dark Minimalist Foundation:** A base layer of tiered obsidian charcoal and true black surfaces that maximize contrast without producing optical vibration.
- **Controlled Luminescence:** Neon emerald and amber glow effects reserved strictly for active states, conversion actions, player controls, and elite status tiers (VIP, 4K, Dolby Atmos).
- **Surface Translucency:** Optical blur layers mimicking smoked acrylic glass to float navigation and contextual actions effortlessly over full-bleed media banners.

## Colors

The palette relies on absolute darkness punctured by focused bursts of high-saturation energy. 

- **Primary (`#00FF87` - Electric Emerald):** High-voltage green used for primary calls to action, currently active tabs, playheads, live badges, and success states. It represents modern sonic energy and rural vitality.
- **Secondary (`#FFB800` - Radiant Amber):** A rich, cinematic gold used exclusively for premium monetization touchpoints: VIP passes, original release labels, star ratings, and award recognition.
- **Tertiary (`#60EFFF` - Cyan Frost):** Technical metadata indicator for resolution cues (4K UHD, HDR10+, Spatial Audio) and secondary audio/subtitle selections.
- **Neutral Surface Palette:**
  - `Canvas Deep`: `#05070A` (Primary screen background, letterbox margins)
  - `Surface Obsidian`: `#0B0E14` (Default card backgrounds, carousels, sheet drawers)
  - `Surface Charcoal`: `#151B26` (Elevated cards, flyout menus, player controls)
  - `Border Smoked`: `rgba(255, 255, 255, 0.08)` (Subtle separation for cards and dividers)
  - `Text High-Contrast`: `#FFFFFF` (Titles, prominent CTAs)
  - `Text Muted`: `#8E9AA8` (Metadata, episode descriptions, timestamps)
  - `Text Dim`: `#4F5969` (Footers, inactive icons, placeholder elements)

Always apply dark background scrims (`linear-gradient(180deg, rgba(5,7,10,0) 0%, rgba(5,7,10,0.85) 70%, #05070A 100%)`) over imagery to guarantee absolute typography legibility.

## Typography

Plus Jakarta Sans governs the entire interface. Its geometric construction delivers punchy title presence across large billboards and TV screens, while remaining razor-sharp in small-scale technical metadata badges.

- **Display & Billboard Scales:** `display-hero` is reserved for featured carousel hero titles, billboard launch campaigns, and hero modal highlights.
- **Section Headlines:** `headline-lg` and `headline-md` anchor rows and content carousels ("Trending Now in Haryana", "Ragni & Folk Originals").
- **Technical & Format Metadata:** `label-caps` in uppercase styling with deliberate tracking (+0.08em) is strictly applied to format badges ("4K UHD", "U/A 16+", "DOLBY 5.1").

## Layout & Spacing

The layout is built upon an edge-to-edge cinematic fluid system with strict horizontal track discipline.

### Breakpoints & Canvas Margins
- **Mobile (< 768px):** Outer horizontal canvas margins are locked to `margin` (16px), with inner carousel gutters of `space-sm` (8px). Hero billboard snaps edge-to-edge with no padding.
- **Tablet (768px - 1024px):** Margins expand to `margin-tablet` (32px), with column gutters of 16px.
- **Desktop & TV (> 1024px):** Margins expand to `margin-desktop` (64px), using a max-width content container of 1680px for wide layouts.

### Structural Flow
- Vertical rhythm between horizontal carousel rails requires `space-xl` (40px) to prevent card thumbnail collisions and preserve distinct category hierarchy.
- Interactive controls and player scrub elements mandate a minimum 44px tap target envelope regardless of visual element height.

## Elevation & Depth

Visual hierarchy uses smoke-tinted glassmorphism coupled with subtle neon edge luminescence. Drop shadows are strictly diffused and directional to create theater-grade isolation.

- **Level 0 (Canvas Base):** Solid `#05070A`. Raw backdrop for media carousels and hero image bleed.
- **Level 1 (Card & Rail Containers):** Solid `#0B0E14` or subtle translucent fills (`rgba(11, 14, 20, 0.7)` with `backdrop-filter: blur(12px)`) bordered with a microscopic hairline: `1px solid rgba(255, 255, 255, 0.06)`.
- **Level 2 (Overlays, Floating Player UI, Bottom Nav):** Smoked glass `rgba(15, 20, 28, 0.85)` with `backdrop-filter: blur(20px)` and an ambient shadow `0 8px 32px -4px rgba(0, 0, 0, 0.7)`.
- **Level 3 (Focused & Active States):** Ambient emerald illumination `0 0 24px -2px rgba(0, 255, 135, 0.35)` with an inner ring of `1px solid #00FF87`.
- **VIP & Premium Surfaces:** Directional gold border gradient `linear-gradient(135deg, #FFB800 0%, rgba(255, 184, 0, 0.1) 50%, #FFB800 100%)` reinforced by a soft golden halo `0 12px 40px -8px rgba(255, 184, 0, 0.25)`.

## Shapes

The design uses balanced rounding (`roundedness: 2`, 8px standard) to convey precision hardware aesthetics rather than bubbly consumer app tropes.

- **Media Posters & Thumbnails:** 8px (`rounded-md`). Provides clean structural boundaries that do not clip video frame details.
- **Glass Floating Navigation & Action Panels:** 16px (`rounded-lg`) to distinctively detach floating controls from underlying media.
- **Badges, Tags, & Indicator Pills:** Fully pill-shaped (`9999px`) to immediately signal interactive or metadata status distinct from thumbnail cards.

## Components

### Buttons & Interactive Triggers
- **Primary Play Button:** Solid `#00FF87` fill with dark `#05070A` bold typography. Hover/Focus state triggers an emerald diffuse glow (`box-shadow: 0 0 20px rgba(0, 255, 135, 0.4)`).
- **Secondary Watchlist / Info Button:** Smoked acrylic background (`rgba(255, 255, 255, 0.1)`) with crisp white icon/text, 1px border `rgba(255, 255, 255, 0.12)`, and 20px backdrop blur.
- **VIP Conversion Button:** Deep metallic gold gradient fill (`linear-gradient(90deg, #FFB800 0%, #FFA000 100%)`) with black high-weight typography.

### OTT Carousels & Video Cards
- **Standard Vertical Poster (2:3 Aspect Ratio):** Optimized for movies and character-led dramas. Contains top-right quality pill ("4K") and bottom gradient overlay hosting content genre tags.
- **Landscape Poster (16:9 Aspect Ratio):** Used for episodes, live music shows, and comedy events. Displays an inline progress bar at the bottom border: 3px height with `#00FF87` representing played percentage.
- **Hover/Focus State:** Subtle 1.04x scale transform with a 200ms ease curve, revealing the title and a floating play button overlay, accented by a 1px border glow.

### Badges & Content Pills
- **VIP Badge:** Deep amber container `rgba(255, 184, 0, 0.15)` with `#FFB800` border and bold gold text.
- **Quality Specs (4K, HDR, 5.1):** Smoked dark container `rgba(0, 0, 0, 0.6)` with `#60EFFF` or neutral white typography.
- **Live Indicator:** Red pill with an animated glowing pulse dot followed by bold white text.

### Floating Bottom Navigation (Mobile)
- Docked 16px above the home indicator, constructed with smoked glass (`rgba(11, 14, 20, 0.85)` + 24px blur).
- Icons use neutral `#8E9AA8` in resting states. Active tab switches to `#00FF87` with an active 4px emerald indicator dot beneath.

### Video Player Controls
- **Scrubber Bar:** Unplayed track in `rgba(255, 255, 255, 0.2)`; buffered segment in `rgba(255, 255, 255, 0.4)`; played track in high-glow `#00FF87`.
- **Center Canvas Overlay:** Translucent dark circle with white play/pause glyphs, fading automatically after 3 seconds of inactivity.

### VIP Subscription Cards
- Feature a dark obsidian background wrapped in a 1.5px metallic gradient border transitioning from `#FFB800` to transparent obsidian.
- Highlighted savings badges use bold emerald fills to maximize conversion contrast against the gold header elements.